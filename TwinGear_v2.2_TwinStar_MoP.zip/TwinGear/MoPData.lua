local _, TG = ...

TG.WORLD_BOSSES = {
    { name = "Sha of Anger", q = 32099 }, { name = "Galleon", q = 32098 },
    { name = "Nalak", q = 32518 }, { name = "Oondasta", q = 32519 },
    { name = "Celestials", q = 33117 }, { name = "Ordos", q = 33118 }
}
TG.CURRENCIES = {
    { id = 777, short = "Timeless Coin" }, { id = 396, short = "Valor" },
    { id = 395, short = "Justice" }, { id = 776, short = "Warforged Seal" }, { id = 738, short = "Lesser Charm" }
}
TG.LEGENDARY_CLOAKS, TG.EPIC_CLOAKS, TG.SET_LOOKUP = {}, {}, {}
for _, id in ipairs({ 102245, 102246, 102247, 102248, 102249, 102250 }) do TG.LEGENDARY_CLOAKS[id] = true end
for _, id in ipairs({ 98146, 98147, 98148, 98149, 98150, 98335 }) do TG.EPIC_CLOAKS[id] = true end

TG.TIER_SETS = {
    T14 = { 85299,85300,85301,85302,85303, 86639,86640,86641,86642,86643, 86923,86924,86925,86926,86927, 85304,85305,85306,85307,85308, 86644,86645,86646,86647,86648, 86928,86929,86930,86931,86932 },
    T15 = { 95225,95226,95227,95228,95229, 95825,95826,95827,95828,95829, 96569,96570,96571,96572,96573, 95230,95231,95232,95233,95234, 95830,95831,95832,95833,95834, 96574,96575,96576,96577,96578 },
    T16 = { 99006,99007,99008,99009,99010, 99144,99145,99146,99147,99148, 99357,99358,99359,99360,99361, 99668,99669,99670,99671,99672, 99011,99012,99013,99014,99015, 99362,99363,99364,99365,99366 }
}
for tier, ids in pairs(TG.TIER_SETS) do for _, id in ipairs(ids) do TG.SET_LOOKUP[id] = tier end end

function TG:GetMyWorldBosses()
    local res = {}
    for _, wb in ipairs(TG.WORLD_BOSSES) do table.insert(res, { name = wb.name, killed = IsQuestFlaggedCompleted(wb.q) and true or false }) end
    return res
end
function TG:GetMyCurrencies()
    local res = {}
    for _, c in ipairs(TG.CURRENCIES) do local n, a = GetCurrencyInfo(c.id); table.insert(res, { id = c.id, label = (n and n ~= "" and n) or c.short, amount = a or 0 }) end
    return res
end
function TG:SaveCurrentAlt(d)
    if not d or not d.isSelf then return end
    TwinGearDB = TwinGearDB or {}; TwinGearDB.alts = TwinGearDB.alts or {}
    local p1, p2 = GetProfessions()
    local pr = {}
    for _, idx in ipairs({p1, p2}) do
        if idx then local n, _, r, m = GetProfessionInfo(idx); if n then table.insert(pr, { name = n, skill = r .. "/" .. m }) end end
    end
    local si = GetSpecialization()
    local specName = si and select(2, GetSpecializationInfo(si)) or ""
    local className = UnitClass("player") or ""
    local rList = TG.GetMyRaids and TG:GetMyRaids() or {}
    local soo = rList[1] and string.format("SoO %d/%d", rList[1].clr or 0, rList[1].total or 14) or ""
    local key = (UnitName("player") or "Unknown") .. "-" .. (GetRealmName() or "TwinStar")
    TwinGearDB.alts[key] = {
        name = UnitName("player"), realm = GetRealmName(), spec = specName .. " " .. className,
        level = UnitLevel("player") or 90, ilvl = d.ilvl or 0, wb = TG:GetMyWorldBosses(), profs = pr, raid = soo
    }
end

function TG:GetWeeklyExtras()
    local sealDone = (IsQuestFlaggedCompleted(33133) or IsQuestFlaggedCompleted(33134)) and true or false
    local ordosDone = IsQuestFlaggedCompleted(33118) and true or false
    local hasLegCloak = false
    local backLink = GetInventoryItemLink("player", 15)
    if backLink then
        local id = tonumber(string.match(backLink, "item:(%d+)"))
        if id and TG.LEGENDARY_CLOAKS and TG.LEGENDARY_CLOAKS[id] then hasLegCloak = true end
    end
    return sealDone, ordosDone, hasLegCloak
end

SLASH_TGCLEARALTS1 = "/tgclearalts"
SlashCmdList["TGCLEARALTS"] = function()
    if TwinGearDB then TwinGearDB.alts = {} end
    DEFAULT_CHAT_FRAME:AddMessage("|cffffd100Twin|r|cff00ff00Gear|r v2.6: Account alts list cleared.")
    if TG.RefreshPage4 then TG:RefreshPage4() end
end
