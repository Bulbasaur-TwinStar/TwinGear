local _, TG = ...
TG.Locales = {
    enUS = {
        TITLE = "TwinGear 3.0", SUBTITLE = "For TwinStar Helios & Persés",
        TAB_SUMMARY = "Overview", TAB_EQUIP = "Equipment", TAB_STATS = "Stats & Caps",
        TAB_PVE = "Raids & Bosses", TAB_ALTS = "Account Alts", TAB_GROUP = "Group Scan",
        SEC_AUDIT = "Gear & Upgrade Audit", SEC_PVE = "MoP Raids & World Bosses",
        SEC_CURR = "Timeless Isle & Currencies", SEC_STATS = "Class & Spec Analysis",
        AUD_ILVL = "Equipped iLvl:", AUD_CLOAK = "Legendary Cloak:", AUD_SETS = "Tier Sets (T14-T16):",
        AUD_UPG = "Upgrades / Reforge:", AUD_GEMS = "Gems / Enchants:", AUD_ARMOR = "Armor Spec (+5%):",
        AUD_PROFS = "Professions:", WB_TITLE = "Weekly World Bosses", CM_TITLE = "Challenge Modes:",
        OK = "OK", MISSING = "Missing", NONE = "None", DONE = "Killed", AVAIL = "Available",
        LANG_NAME = "English", ALT_HINT = "All characters logged in on this account:"
    },
    csCZ = {
        TITLE = "TwinGear 3.0", SUBTITLE = "For TwinStar Helios & Persés",
        TAB_SUMMARY = "Přehled", TAB_EQUIP = "Výbava", TAB_STATS = "Staty & Capy",
        TAB_PVE = "Raidy & Bossové", TAB_ALTS = "Alti na účtu", TAB_GROUP = "Sken skupiny",
        SEC_AUDIT = "Audit výbavy a upgradů", SEC_PVE = "MoP Raidy & World Bossové",
        SEC_CURR = "Timeless Isle & Měny", SEC_STATS = "Analýza classy a specu",
        AUD_ILVL = "Vybavené iLvl:", AUD_CLOAK = "Legendární plášť:", AUD_SETS = "Setové bonusy (T14-T16):",
        AUD_UPG = "Upgrady / Reforge:", AUD_GEMS = "Gemy / Enchanty:", AUD_ARMOR = "Správná zbroj (+5%):",
        AUD_PROFS = "Profese:", WB_TITLE = "Týdenní World Bossové", CM_TITLE = "Challenge Mody:",
        OK = "OK", MISSING = "Chybí", NONE = "Neaktivní", DONE = "Zabito", AVAIL = "Volný",
        LANG_NAME = "Čeština", ALT_HINT = "Všechny postavy přihlášené na tomto účtu:"
    },
    skSK = {
        TITLE = "TwinGear 3.0", SUBTITLE = "For TwinStar Helios & Persés",
        TAB_SUMMARY = "Prehľad", TAB_EQUIP = "Výbava", TAB_STATS = "Štaty & Capy",
        TAB_PVE = "Raidy & Bossovia", TAB_ALTS = "Alti na účte", TAB_GROUP = "Sken skupiny",
        SEC_AUDIT = "Audit výbavy a upgradov", SEC_PVE = "MoP Raidy & World Bossovia",
        SEC_CURR = "Timeless Isle & Meny", SEC_STATS = "Analýza classy a specu",
        AUD_ILVL = "Vybavené iLvl:", AUD_CLOAK = "Legendárny plášť:", AUD_SETS = "Setové bonusy (T14-T16):",
        AUD_UPG = "Upgrady / Reforge:", AUD_GEMS = "Gemy / Enchanty:", AUD_ARMOR = "Správna zbroj (+5%):",
        AUD_PROFS = "Profesie:", WB_TITLE = "Týždenní World Bossovia", CM_TITLE = "Challenge Mody:",
        OK = "OK", MISSING = "Chýba", NONE = "Neaktívne", DONE = "Zabitý", AVAIL = "Voľný",
        LANG_NAME = "Slovenčina", ALT_HINT = "Všetky postavy prihlásené na tomto účte:"
    }
}
function TG:L(k)
    local lang = (TwinGearDB and TwinGearDB.lang) or "csCZ"
    return (TG.Locales[lang] and TG.Locales[lang][k]) or TG.Locales.enUS[k] or k
end
